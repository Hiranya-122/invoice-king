# Invoice Generator - DBMS Microproject

A simple invoice generator application with:
- Customer management
- Invoice creation
- Itemized billing
- Data persistence with SQLite

## Features
- Create and manage customers
- Generate invoices with multiple items
- View invoice history
- Responsive web interface

## Installation
1. Clone the repository
2. Run `npm install`
3. Start the server with `npm start`
4. Access the application at `http://localhost:3000`

## Technologies
- Node.js with Express
- SQLite database
- HTML/CSS/JavaScript frontend